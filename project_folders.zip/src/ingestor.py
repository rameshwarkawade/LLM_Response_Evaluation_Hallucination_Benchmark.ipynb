
import json
from pathlib import Path


def load_dataset(path):
    """
    Load the benchmark dataset from a JSON file.

    The dataset can either be:
    - a list of evaluation cases
    - a dictionary containing an "examples" or "data" list
    """

    path = Path(path)

    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {path}"
        )

    with open(
        path,
        "r",
        encoding="utf-8"
    ) as file:

        data = json.load(file)

    if isinstance(data, list):
        return data

    if isinstance(data, dict):

        if isinstance(data.get("examples"), list):
            return data["examples"]

        if isinstance(data.get("data"), list):
            return data["data"]

        if isinstance(data.get("cases"), list):
            return data["cases"]

    raise ValueError(
        "Unsupported dataset format. "
        "Expected a list or a dictionary "
        "containing examples/data/cases."
    )

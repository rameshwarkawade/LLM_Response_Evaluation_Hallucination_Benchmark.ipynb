
def calculate_binary_metrics(
    y_true,
    y_pred
):
    """
    Calculate binary classification metrics.

    Positive class:
        hallucinated

    Negative class:
        grounded
    """

    tp = 0
    fp = 0
    fn = 0
    tn = 0

    for actual, predicted in zip(
        y_true,
        y_pred
    ):

        if actual == "hallucinated" and predicted == "hallucinated":
            tp += 1

        elif actual == "grounded" and predicted == "hallucinated":
            fp += 1

        elif actual == "hallucinated" and predicted == "grounded":
            fn += 1

        elif actual == "grounded" and predicted == "grounded":
            tn += 1

    precision = (
        tp / (tp + fp)
        if (tp + fp)
        else 0.0
    )

    recall = (
        tp / (tp + fn)
        if (tp + fn)
        else 0.0
    )

    if precision + recall:
        f1 = (
            2 * precision * recall
            / (precision + recall)
        )
    else:
        f1 = 0.0

    return {
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "tn": tn,
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(f1, 4)
    }

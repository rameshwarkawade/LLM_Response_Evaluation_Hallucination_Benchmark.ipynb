
import spacy


nlp = spacy.load("en_core_web_sm")


def extract_claims(text):
    """
    Split an LLM response into individual claims.
    """

    if not text or not text.strip():
        return []

    doc = nlp(text)

    claims = []

    for sentence in doc.sents:
        claim = sentence.text.strip()

        if claim:
            claims.append(claim)

    return claims


def count_claims(text):
    """
    Return the number of claims found in a response.
    """

    claims = extract_claims(text)

    return len(claims)


from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity


model = SentenceTransformer("all-MiniLM-L6-v2")


def split_source(source):
    """
    Split the reference text into individual evidence sentences.
    """

    sentences = []

    for sentence in source.split("."):
        sentence = sentence.strip()

        if sentence:
            sentences.append(sentence)

    return sentences


def find_best_match(claim, source):
    """
    Find the source sentence that is most similar to a claim.
    """

    source_sentences = split_source(source)

    if not source_sentences:
        return {
            "score": 0.0,
            "evidence": None
        }

    claim_embedding = model.encode([claim])
    source_embeddings = model.encode(source_sentences)

    scores = cosine_similarity(
        claim_embedding,
        source_embeddings
    )[0]

    best_index = scores.argmax()

    return {
        "score": float(scores[best_index]),
        "evidence": source_sentences[best_index]
    }


def evaluate_claim(claim, source, threshold=0.60):
    """
    Evaluate whether a claim is sufficiently supported by the source.
    """

    result = find_best_match(claim, source)

    score = result["score"]

    if score >= threshold:
        label = "grounded"
    else:
        label = "unsupported"

    return {
        "claim": claim,
        "score": round(score, 4),
        "evidence": result["evidence"],
        "label": label
    }

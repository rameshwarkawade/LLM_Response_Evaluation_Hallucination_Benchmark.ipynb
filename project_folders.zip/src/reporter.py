
import re


def extract_numbers(text):
    """
    Extract numeric values from text.
    """

    if not text:
        return []

    return re.findall(
        r"\b\d+(?:\.\d+)?\b",
        text
    )


def has_number_conflict(
    claim,
    evidence
):
    """
    Detect whether claim and evidence contain
    different numerical values.
    """

    claim_numbers = extract_numbers(claim)
    evidence_numbers = extract_numbers(evidence)

    if not claim_numbers or not evidence_numbers:
        return False

    return claim_numbers != evidence_numbers


def detect_error_type(result):
    """
    Assign a detailed error category using
    evidence, similarity and NLI output.
    """

    claim = result.get(
        "claim",
        ""
    )

    evidence = result.get(
        "evidence",
        ""
    )

    verdict = result.get(
        "label"
    )

    relation = result.get(
        "relation"
    )

    similarity = result.get(
        "score",
        0.0
    )

    if verdict == "grounded":
        return {
            "error_type": "None",
            "severity": "None",
            "reason": (
                "The claim is supported by the available evidence."
            )
        }

    if relation == "contradiction":

        if has_number_conflict(
            claim,
            evidence
        ):
            return {
                "error_type": "Numerical Error",
                "severity": "High",
                "reason": (
                    "The claim contains a numerical value "
                    "that conflicts with the evidence."
                )
            }

        return {
            "error_type": "Factual Contradiction",
            "severity": "High",
            "reason": (
                "The claim conflicts with the available evidence."
            )
        }

    if verdict == "unsupported":

        if similarity < 0.40:
            return {
                "error_type": "Missing Evidence",
                "severity": "Medium",
                "reason": (
                    "No sufficiently similar evidence was found "
                    "for the claim."
                )
            }

        return {
            "error_type": "Unsupported Claim",
            "severity": "Medium",
            "reason": (
                "The available evidence does not sufficiently "
                "support the claim."
            )
        }

    if verdict == "supported_candidate":

        return {
            "error_type": "Needs Human Review",
            "severity": "Low",
            "reason": (
                "The claim is semantically similar to the evidence, "
                "but the evidence relationship is uncertain."
            )
        }

    return {
        "error_type": "Needs Human Review",
        "severity": "Low",
        "reason": (
            "The automated evaluator could not confidently "
            "classify the claim."
        )
    }


def build_audit_record(
    result,
    claim_id=None
):
    """
    Create a detailed claim-level audit record.
    """

    error = detect_error_type(
        result
    )

    return {
        "claim_id": claim_id,
        "claim": result.get("claim"),
        "evidence": result.get("evidence"),
        "similarity_score": result.get("score"),
        "nli_relation": result.get("relation"),
        "verdict": result.get("label"),
        "error_type": error["error_type"],
        "severity": error["severity"],
        "reason": error["reason"]
    }


def build_audit_report(results):
    """
    Convert evaluator results into audit records.
    """

    report = []

    for index, result in enumerate(
        results,
        start=1
    ):

        report.append(
            build_audit_record(
                result,
                claim_id=index
            )
        )

    return report


def calculate_summary(
    audit_report
):
    """
    Calculate high-level evaluation metrics.
    """

    total_claims = len(
        audit_report
    )

    grounded = sum(
        item["verdict"] == "grounded"
        for item in audit_report
    )

    contradictions = sum(
        item["verdict"] == "contradiction"
        for item in audit_report
    )

    unsupported = sum(
        item["verdict"] == "unsupported"
        for item in audit_report
    )

    review = sum(
        item["verdict"] == "supported_candidate"
        for item in audit_report
    )

    faithfulness = (
        grounded / total_claims * 100
        if total_claims
        else 0.0
    )

    return {
        "total_claims": total_claims,
        "grounded_claims": grounded,
        "contradictions": contradictions,
        "unsupported_claims": unsupported,
        "needs_review": review,
        "faithfulness_score": round(
            faithfulness,
            2
        )
    }


def calculate_benchmark_metrics(
    dataframe
):
    """
    Calculate benchmark-level metrics.
    """

    total_claims = len(
        dataframe
    )

    grounded = (
        dataframe["verdict"] == "grounded"
    ).sum()

    contradictions = (
        dataframe["verdict"] == "contradiction"
    ).sum()

    unsupported = (
        dataframe["verdict"] == "unsupported"
    ).sum()

    review = (
        dataframe["verdict"]
        == "supported_candidate"
    ).sum()

    faithfulness = (
        grounded / total_claims * 100
        if total_claims
        else 0.0
    )

    return {
        "total_claims": int(
            total_claims
        ),
        "grounded_claims": int(
            grounded
        ),
        "contradictions": int(
            contradictions
        ),
        "unsupported_claims": int(
            unsupported
        ),
        "needs_review": int(
            review
        ),
        "faithfulness_score": round(
            faithfulness,
            2
        )
    }

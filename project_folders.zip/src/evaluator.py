
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

from src.contradiction import predict_relation


model = SentenceTransformer(
    "all-MiniLM-L6-v2"
)


def split_source(source):
    """
    Split reference text into evidence sentences.
    """

    sentences = []

    for sentence in source.split("."):

        sentence = sentence.strip()

        if sentence:
            sentences.append(sentence)

    return sentences


def find_best_match(claim, source):
    """
    Find the strongest semantic evidence for a claim.
    """

    source_sentences = split_source(source)

    if not source_sentences:
        return {
            "score": 0.0,
            "evidence": None
        }

    claim_embedding = model.encode(
        [claim]
    )

    source_embeddings = model.encode(
        source_sentences
    )

    scores = cosine_similarity(
        claim_embedding,
        source_embeddings
    )[0]

    best_index = scores.argmax()

    return {
        "score": float(
            scores[best_index]
        ),
        "evidence": source_sentences[
            best_index
        ]
    }


def evaluate_claim(
    claim,
    source,
    threshold=0.60
):
    """
    Evaluate a claim using semantic similarity
    and contradiction detection.
    """

    match = find_best_match(
        claim,
        source
    )

    similarity_score = match["score"]
    evidence = match["evidence"]

    if evidence is None:
        return {
            "claim": claim,
            "score": 0.0,
            "evidence": None,
            "relation": "neutral",
            "label": "unsupported"
        }

    relation = predict_relation(
        claim,
        evidence
    )

    relation_label = relation["label"]

    if relation_label == "contradiction":
        final_label = "contradiction"

    elif (
        relation_label == "entailment"
        and similarity_score >= threshold
    ):
        final_label = "grounded"

    elif similarity_score >= threshold:
        final_label = "supported_candidate"

    else:
        final_label = "unsupported"

    return {
        "claim": claim,
        "score": round(
            similarity_score,
            4
        ),
        "evidence": evidence,
        "relation": relation_label,
        "label": final_label
    }

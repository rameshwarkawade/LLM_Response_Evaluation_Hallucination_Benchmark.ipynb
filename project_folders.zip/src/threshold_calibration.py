
from src.evaluator import evaluate_claim
from src.atomic_claims import extract_atomic_claims
from src.metrics import calculate_binary_metrics


def predict_test_case(
    test_case,
    threshold
):
    """
    Produce a binary hallucination prediction
    for one test case.

    A response is considered hallucinated if
    at least one extracted claim is classified
    as unsupported or contradictory.
    """

    source = test_case.get(
        "source",
        ""
    )

    response = test_case.get(
        "response",
        ""
    )

    claims = extract_atomic_claims(
        response
    )

    if not claims:
        return "grounded"

    for claim in claims:

        result = evaluate_claim(
            claim,
            source,
            threshold=threshold
        )

        if result["label"] in {
            "unsupported",
            "contradiction"
        }:
            return "hallucinated"

    return "grounded"


def evaluate_threshold(
    dataset,
    threshold
):
    """
    Evaluate one similarity threshold.
    """

    y_true = []
    y_pred = []

    for test_case in dataset:

        actual = str(
            test_case.get(
                "human_label",
                ""
            )
        ).lower().strip()

        if actual not in {
            "grounded",
            "hallucinated"
        }:
            continue

        prediction = predict_test_case(
            test_case,
            threshold
        )

        y_true.append(actual)
        y_pred.append(prediction)

    metrics = calculate_binary_metrics(
        y_true,
        y_pred
    )

    metrics["threshold"] = threshold
    metrics["samples"] = len(y_true)

    return metrics

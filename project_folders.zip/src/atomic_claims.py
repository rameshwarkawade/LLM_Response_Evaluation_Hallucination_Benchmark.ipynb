
import spacy


nlp = spacy.load("en_core_web_sm")


def clean_claim(text):
    """
    Clean whitespace and punctuation from a claim.
    """

    return " ".join(text.strip().split()).strip(" ,;")


def split_conjunction(sentence):
    """
    Split simple coordinated clauses into separate claims.

    This is intentionally conservative. It only splits when
    spaCy identifies coordinated predicates or clauses.
    """

    doc = nlp(sentence)

    claims = []

    for token in doc:

        if token.dep_ != "conj":
            continue

        if token.pos_ not in {"VERB", "AUX"}:
            continue

        first_part = []

        for child in token.children:

            if child.dep_ in {
                "nsubj",
                "nsubjpass"
            }:
                first_part.append(child)

        if not first_part:
            continue

        subject = first_part[0].subtree
        subject_text = " ".join(
            word.text for word in subject
        )

        first_claim = (
            f"{subject_text} "
            f"{token.text} "
        )

        for child in token.children:

            if child.dep_ not in {
                "nsubj",
                "nsubjpass"
            }:
                first_claim += child.text + " "

        first_claim = clean_claim(first_claim)

        if first_claim:
            claims.append(first_claim)

    return claims


def extract_atomic_claims(text):
    """
    Extract sentence-level and simple atomic claims.
    """

    if not text or not text.strip():
        return []

    doc = nlp(text)

    atomic_claims = []

    for sentence in doc.sents:

        sentence_text = clean_claim(
            sentence.text
        )

        if not sentence_text:
            continue

        split_claims = split_conjunction(
            sentence_text
        )

        if split_claims:
            atomic_claims.extend(
                split_claims
            )
        else:
            atomic_claims.append(
                sentence_text
            )

    return atomic_claims


def extract_claim_records(text):
    """
    Return atomic claims with stable IDs.
    """

    claims = extract_atomic_claims(text)

    records = []

    for index, claim in enumerate(
        claims,
        start=1
    ):
        records.append({
            "claim_id": index,
            "claim": claim
        })

    return records

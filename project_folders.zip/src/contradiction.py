
from sentence_transformers import CrossEncoder


MODEL_NAME = "cross-encoder/nli-deberta-v3-base"

model = CrossEncoder(MODEL_NAME)


LABELS = {
    0: "contradiction",
    1: "entailment",
    2: "neutral"
}


def predict_relation(claim, evidence):
    """
    Predict the relationship between a claim and its evidence.

    Returns:
        contradiction
        entailment
        neutral
    """

    if not claim or not evidence:
        return {
            "label": "neutral",
            "scores": {}
        }

    scores = model.predict(
        [(evidence, claim)]
    )[0]

    probabilities = {
        LABELS[index]: float(score)
        for index, score in enumerate(scores)
    }

    predicted_label = max(
        probabilities,
        key=probabilities.get
    )

    return {
        "label": predicted_label,
        "scores": probabilities
    }

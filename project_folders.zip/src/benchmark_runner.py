
import json
from pathlib import Path

import pandas as pd

from src.atomic_claims import extract_atomic_claims
from src.evaluator import evaluate_claim
from src.reporter import build_audit_record


def load_dataset(file_path):
    """
    Load benchmark examples from a JSON file.
    """

    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {file_path}"
        )

    with open(
        path,
        "r",
        encoding="utf-8"
    ) as file:

        data = json.load(file)

    if not isinstance(data, list):
        raise ValueError(
            "Benchmark dataset must contain a list of examples."
        )

    return data


def evaluate_test_case(
    test_case,
    threshold=0.60
):
    """
    Evaluate all claims in one test case.
    """

    source = test_case.get(
        "source",
        ""
    )

    response = test_case.get(
        "response",
        ""
    )

    test_id = test_case.get(
        "test_id",
        "unknown"
    )

    claims = extract_atomic_claims(
        response
    )

    records = []

    for claim_number, claim in enumerate(
        claims,
        start=1
    ):

        result = evaluate_claim(
            claim,
            source,
            threshold=threshold
        )

        audit_record = build_audit_record(
            result,
            claim_id=f"{test_id}_{claim_number}"
        )

        audit_record["test_id"] = test_id

        records.append(
            audit_record
        )

    return records


def run_benchmark(
    dataset_path,
    threshold=0.60
):
    """
    Run the evaluator across the complete benchmark dataset.
    """

    dataset = load_dataset(
        dataset_path
    )

    all_records = []

    print(
        f"Running benchmark on {len(dataset)} test cases..."
    )

    for index, test_case in enumerate(
        dataset,
        start=1
    ):

        records = evaluate_test_case(
            test_case,
            threshold=threshold
        )

        all_records.extend(records)

        if index % 10 == 0:
            print(
                f"Processed {index}/{len(dataset)} cases"
            )

    return pd.DataFrame(
        all_records
    )


def save_benchmark_results(
    dataframe,
    output_path
):
    """
    Save benchmark results as CSV.
    """

    output = Path(output_path)

    output.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    dataframe.to_csv(
        output,
        index=False
    )

    print(
        f"Results saved to: {output}"
    )

import streamlit as st
import pandas as pd
import numpy as np
import joblib

# Page Configuration
st.set_page_config(
    page_title="AI-Powered Retail Intelligence Platform",
    page_icon="📊",
    layout="wide"
)

# Load Machine Learning Model
model = joblib.load("Retail_Profit_Predictor.pkl")

# Load Dataset
df = pd.read_csv("Retail_Feature_Engineered.csv")

# Title
st.title("📊 AI-Powered Retail Intelligence Platform")

st.markdown("""
### Welcome!

This application predicts **Retail Profit** using a Machine Learning model.

### Technologies Used
- Python
- Pandas
- Scikit-learn
- Streamlit
- Machine Learning

---
""")

# ---------------- Sidebar ----------------

st.sidebar.title("📌 Navigation")

page = st.sidebar.radio(
    "Go to",
    [
        "🏠 Home",
        "📊 Dataset",
        "🤖 Profit Prediction",
        "📈 Model Performance",
        "ℹ️ About"
    ]
)

# ---------------- Home ----------------

if page == "🏠 Home":

    st.header("🏠 Home")

    st.write("""
Welcome to the AI-Powered Retail Intelligence Platform.

This project performs:

✔ Data Cleaning

✔ Exploratory Data Analysis

✔ SQL Analysis

✔ Feature Engineering

✔ Machine Learning

✔ Profit Prediction

✔ Interactive Dashboard
""")

    st.subheader("Dataset Overview")

    col1, col2 = st.columns(2)

    with col1:
        st.metric("Rows", df.shape[0])

    with col2:
        st.metric("Columns", df.shape[1])

    st.dataframe(df.head())